# -*- coding: utf-8 -*-

"""
Created on Tue Aug 16 19:40:57 2023

@author: Manon Leconte
"""


###Chargement des bibliothèques

import matplotlib.pyplot as plt
import numpy as np


###Couleurs

bleuvert=(0,.5,.5)
violet=(.5,0,.5)
jaunefonce=(.5,.5,0)


###Input

data = np.loadtxt('donnees_chute_libre.txt') # import depuis le fichier des données
moyenne=np.average(data)
ecart_type=np.std(data, ddof = 1)


###Visualisation des données

plt.plot(data,marker='o',color=bleuvert)
plt.axhline(y=moyenne+3*ecart_type,linewidth=1,ls=':',color=violet)#Droite y = moyenne + 3 * sigma
plt.annotate("$t_{moy}+3\sigma$",(1,moyenne+3*ecart_type),color=violet)
plt.axhline(y=moyenne-3*ecart_type,linewidth=1,ls=':',color=violet)#Droite y = moyenne - 3 * sigma
plt.annotate("$t_{moy}-3\sigma$",(1,moyenne-3*ecart_type),color=violet)
plt.title("Distribution des temps de chute")
plt.ylabel("Temps de chute $t$ (s)")

plt.show()


###Test de Grubbs

data_min=min(data)
data_max=max(data)

def G1(mu,m,sigma):
    return (mu-m)/sigma
def G2(mu,M,sigma):
    return (-mu+M)/sigma

Gmin=G1(moyenne,data_min,ecart_type)
Gmax=G2(moyenne,data_max,ecart_type)

while Gmin>3 or Gmax>3:
    if Gmin>3:
        print(data_min)
        i=np.argmin(data)
        data=np.delete(data,i)
        moyenne=np.average(data)
        ecart_type=np.std(data, ddof = 1)
        data_min=min(data)
        Gmin=G1(moyenne,data_min,ecart_type)
    else:
        print(data_max)
        i=np.argmax(data)
        data=np.delete(data,i)
        moyenne=np.average(data)
        ecart_type=np.std(data, ddof = 1)
        data_max=max(data)
        Gmax=G2(moyenne,data_max,ecart_type)
